import '../models/sensor_reading.dart';
import '../models/irrigation_decision.dart';
import '../models/alert_item.dart';

class DecisionEngine {
  static IrrigationDecision evaluateIrrigation(SensorReading reading) {
    if (reading.rainProbability >= 60.0) {
      return IrrigationDecision(
        status: IrrigationStatus.delay,
        title: 'Delay Irrigation',
        reason: 'Rain forecasted (${reading.rainProbability.toStringAsFixed(0)}%). Postponing watering avoids waterlogging.',
        waterAmountMm: 0.0,
        recommendedDurationMinutes: 0,
        optimalTimeWindow: 'Re-evaluate in 6 hours',
        urgency: 'low',
      );
    }

    if (reading.soilMoisture < 32.0) {
      return IrrigationDecision(
        status: IrrigationStatus.recommended,
        title: 'Urgent Irrigation Recommended',
        reason: 'Critical root-zone moisture deficit (${reading.soilMoisture.toStringAsFixed(1)}%).',
        waterAmountMm: 25.0,
        recommendedDurationMinutes: 45,
        optimalTimeWindow: 'Immediate or dawn (05:00 - 07:00 AM)',
        urgency: 'high',
      );
    }

    if (reading.soilMoisture < 45.0) {
      return IrrigationDecision(
        status: IrrigationStatus.recommended,
        title: 'Maintenance Irrigation Recommended',
        reason: 'Soil moisture (${reading.soilMoisture.toStringAsFixed(1)}%) is below optimal field capacity.',
        waterAmountMm: 15.0,
        recommendedDurationMinutes: 30,
        optimalTimeWindow: 'Evening (05:30 - 07:30 PM)',
        urgency: 'medium',
      );
    }

    return IrrigationDecision(
      status: IrrigationStatus.notRequired,
      title: 'Irrigation Not Required',
      reason: 'Soil moisture (${reading.soilMoisture.toStringAsFixed(1)}%) is within optimal vegetative range.',
      waterAmountMm: 0.0,
      recommendedDurationMinutes: 0,
      optimalTimeWindow: 'Monitoring active',
      urgency: 'low',
    );
  }

  static List<AlertItem> generateAlerts(SensorReading reading, DemoScenario scenario) {
    final List<AlertItem> alerts = [];
    final now = DateTime.now();

    if (scenario == DemoScenario.disease || (reading.humidity > 82.0 && reading.temperature > 26.0)) {
      alerts.add(AlertItem(
        id: 'alt_dis_${now.millisecondsSinceEpoch}',
        type: AlertType.disease,
        severity: AlertSeverity.critical,
        title: 'Fungal Blight Risk Elevated',
        message: 'High humidity (${reading.humidity.toStringAsFixed(0)}%) fosters rapid fungal spore germination.',
        timestamp: now,
        triggerMetric: 'Humidity > 80%',
        recommendedAction: 'Inspect lower leaf canopy; apply Trichoderma viride preventative bio-spray.',
      ));
    }

    if (scenario == DemoScenario.lowMoisture || reading.soilMoisture < 32.0) {
      alerts.add(AlertItem(
        id: 'alt_irr_${now.millisecondsSinceEpoch}',
        type: AlertType.irrigation,
        severity: AlertSeverity.warning,
        title: 'Soil Moisture Depletion',
        message: 'Moisture dropped below 35% critical buffer.',
        timestamp: now,
        triggerMetric: 'Soil Moisture: ${reading.soilMoisture.toStringAsFixed(0)}%',
        recommendedAction: 'Activate Zone 2 irrigation valve for 45 mins.',
      ));
    }

    return alerts;
  }
}