# AGRO-IOT Flutter Android App
SIH Problem Statement 26180 Solution

## Commands to Build & Run:
```bash
flutter pub get
flutter analyze
flutter run
flutter build apk --release
```
Output APK: build/app/outputs/flutter-apk/app-release.apk
